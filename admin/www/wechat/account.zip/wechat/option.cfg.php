<?
$options = array(
	'token'=>'minosweixintoken', //填写你设定的key
	'encodingaeskey'=>'cqGF8EpSgatd3feHMiKOtmqsgHuB6BQvWNpZITRY39y', //填写加密用的EncodingAESKey
	'appid'=>'wxede1e5a9fb3ec78b', //填写高级调用功能的app id
	'appsecret'=>'43081edafeb5da5a5786e0c21eef227a' //填写高级调用功能的密钥
);
?>